<?php  
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
include('include/session_check_doctor.php');

check_login();
date_default_timezone_set('Asia/Kolkata'); // change according to timezone
$currentTime = date('Y-m-d h:i:s', time());

if (isset($_POST['submit'])) {
    // Fetch current password from database for verification
    $sql = mysqli_query($con, "SELECT password FROM doctors WHERE id='" . $_SESSION['id'] . "'");
    $num = mysqli_fetch_array($sql);

    // Verify current password
    if ($num && password_verify($_POST['cpass'], $num['password'])) {
        // Check new password validation criteria
        $newPassword = $_POST['npass'];
        if (!preg_match('/^(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $newPassword)) {
            $_SESSION['msg1'] = "New password must be at least 8 characters long, include at least one uppercase letter, one number, and one special character.";
        } elseif ($_POST['npass'] != $_POST['cfpass']) {
            $_SESSION['msg1'] = "New Password and Confirm Password do not match!";
        } else {
            // Hash the new password using PASSWORD_BCRYPT
            $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
            
            // Update the password in the database
            $con = mysqli_query($con, "UPDATE doctors SET password='$hashedPassword', updationDate='$currentTime' WHERE id='" . $_SESSION['id'] . "'");

            // Success message
            $_SESSION['msg1'] = "Password Changed Successfully!";
        }
    } else {
        $_SESSION['msg1'] = "Old Password does not match!";
    }

    // Redirect to the same page to show the message
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 300);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Doctor | Change Password</title>
    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../assets/css/custom.css" rel="stylesheet">
    <script type="text/javascript">
        function valid() {
            if (document.chngpwd.cpass.value == "") {
                alert("Current Password Field is Empty!!");
                document.chngpwd.cpass.focus();
                return false;
            } else if (document.chngpwd.npass.value == "") {
                alert("New Password Field is Empty!!");
                document.chngpwd.npass.focus();
                return false;
            } else if (document.chngpwd.cfpass.value == "") {
                alert("Confirm Password Field is Empty!!");
                document.chngpwd.cfpass.focus();
                return false;
            } else if (document.chngpwd.npass.value != document.chngpwd.cfpass.value) {
                alert("Password and Confirm Password do not match!!");
                document.chngpwd.cfpass.focus();
                return false;
            }
            return true;
        }
    </script>
</head>
<body class="nav-md">
    <?php
    $page_title = 'Doctor | Change Password';
    $x_content = true;
    ?>
    <?php include('include/header.php'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="row margin-top-30">
                <div class="col-lg-8 col-md-12">
                    <div class="panel panel-white">
                        <div class="panel-heading">
                            <h5 class="panel-title">Change Password</h5>
                        </div>
                        <div class="panel-body">
                            <!-- Display success or error message -->
                            <?php if (isset($_SESSION['msg1'])): ?>
                                <p style="color: red;"><?php echo htmlentities($_SESSION['msg1']); ?></p>
                                <?php unset($_SESSION['msg1']); ?> <!-- Clear the message after displaying it -->
                            <?php endif; ?>
                            
                            <form role="form" name="chngpwd" method="post" onSubmit="return valid();">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Current Password</label>
                                    <input type="password" name="cpass" class="form-control" placeholder="Enter Current Password" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">New Password</label>
                                    <input type="password" name="npass" class="form-control" placeholder="New Password" required>
                                    <small class="text-muted">Password must be at least 8 characters long, include at least one uppercase letter, one number, and one special character.</small>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Confirm Password</label>
                                    <input type="password" name="cfpass" class="form-control" placeholder="Confirm Password" required>
                                </div>
                                <button type="submit" name="submit" class="btn btn-o btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('include/footer.php'); ?>
    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../assets/js/custom.min.js"></script>
    <script>
        let timeout = <?php echo SESSION_TIMEOUT; ?>;
        let countdown = timeout;

        function updateCountdown() {
            countdown--;
            document.getElementById('countdown').innerText = countdown;

            if (countdown <= 0) {
                alert("Your session has expired. Please log in again.");
                window.location.href = "index.php?session_expired=1";
            }
        }

        setInterval(updateCountdown, 1000);
    </script>
</body>
</html>
