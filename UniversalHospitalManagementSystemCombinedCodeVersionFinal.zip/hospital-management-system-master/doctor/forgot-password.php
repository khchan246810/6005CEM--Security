<?php
session_start();
error_reporting(0);
include("include/config.php");
//Checking Details for reset password
define(constant_name: 'ENCRYPTION_KEY', value: 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

function decrypt($dataDecrypt) {
    list($iv, $encrypted) = explode('::', base64_decode($dataDecrypt), 2);
    $cipher = "AES-128-CTR";
    return openssl_decrypt($encrypted, $cipher, ENCRYPTION_KEY, 0, $iv);
}
function encrypt($data) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generate a random IV
    $encrypted = openssl_encrypt($data, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Store IV + Encrypted string
}

if(isset($_POST['submit'])){
	$email=$_POST['email'];
	$query=mysqli_query($con,"select id from  doctors where docEmail='$email'");
	$row=mysqli_num_rows($query);
	if($row>0){

		$_SESSION['email']=$email;
		header('location:reset-password.php');
	} else {
		echo "<script>alert('Invalid details. Please try with valid details');</script>";
		echo "<script>window.location.href ='forgot-password.php'</script>";


	}

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Password Recovery</title>

	<!-- Bootstrap -->
	<link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<!-- NProgress -->
	<link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	<!-- iCheck -->
	<link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
	<!-- bootstrap-progressbar -->
	<link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
	<!-- JQVMap -->
	<link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
	<!-- bootstrap-daterangepicker -->
	<link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
	<!-- Custom Theme Style -->
	<link href="../assets/css/custom.min.css" rel="stylesheet">
</head>
<body class="login">
	<div>
		<a class="hiddenanchor" id="signup"></a>
		<a class="hiddenanchor" id="signin"></a>
		<div class="login_wrapper">
			<div class="animate form login_form">
				<section class="login_content">

					<div class="box-login">
						<form class="form-login" method="post">
							<fieldset>
								<legend>
								Universal Hospital Management System | Doctor Password Recovery
								</legend>
								<p>
									Please enter your Contact number and Email to recover your password.<br />

								</p>

						

								<div class="form-group">
									<span class="input-icon">
										<input type="email" class="form-control" name="email" placeholder="Registered Email">
									</div>

									<div class="form-actions">

										<button type="submit" class="btn btn-primary pull-right" name="submit">
											Reset <i class="fa fa-arrow-circle-right"></i>
										</button>
									</div>
									<div class="new-account">
										Already have an account?
										<a href="index.php">
											Log-in
										</a>
									</div>
								</fieldset>
							</form>

							<div class="copyright">
								&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> Universal Hospital Management System</span>. <span>All rights reserved</span>
							</div>

						</div>
					</section>

				</div>
			</div>

		</body>
		<!-- end: BODY -->
		</html>