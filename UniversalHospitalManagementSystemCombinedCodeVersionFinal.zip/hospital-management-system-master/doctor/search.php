<?php 
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
include('include/session_check_doctor.php');

check_login();

// Define constants
if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 300);
}

define('ENCRYPTION_KEY', 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

// Function to decrypt data
function decrypt($dataDecrypt) {
    list($iv, $encrypted) = explode('::', base64_decode($dataDecrypt), 2);
    $cipher = "AES-128-CTR";
    return openssl_decrypt($encrypted, $cipher, ENCRYPTION_KEY, 0, $iv);
}

// Function to sanitize input
function sanitize_input($input) {
    $input = str_replace("'", "", $input);  // Remove apostrophes
    $input = str_replace('"', "", $input);  // Remove double quotes
    $input = preg_replace('/[^A-Za-z0-9 ]/', '', $input); // Remove all other special characters
    return $input;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Doctor | Manage Patients</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../assets/css/custom.css" rel="stylesheet">
</head>
<body class="nav-md">
    <?php
    $page_title = 'Doctor | Manage Patients';
    $x_content = true;
    ?>
    <?php include('include/header.php'); ?>

    <div class="row">
        <div class="col-md-12">
            <form role="form" method="post" name="search">
                <div class="form-group">
                    <label for="doctorname">
                        Search by Patient Name
                    </label>
                    <input type="text" name="searchdata" id="searchdata" class="form-control" value="" required='true'>
                </div>

                <button type="submit" name="search" id="submit" class="btn btn-o btn-primary">
                    Search
                </button>
            </form>

            <?php
            // Retrieve the logged-in doctor's name from session
            $doctor_name = $_SESSION['doctorName'];  // Assuming the doctorName is stored in session

            if(isset($_POST['search'])) {
                $sdata = sanitize_input($_POST['searchdata']);

                echo '<h4 align="center">Results for "' . $sdata . '" keyword</h4>';

                // Query to fetch patients by patient's name
                $sql = mysqli_query($con, "SELECT * FROM tblpatient WHERE 
                                            (PatientName LIKE '%$sdata%') AND 
                                             DoctorName = '$doctor_name'");

                $num = mysqli_num_rows($sql);
                if($num > 0) {
                    $cnt = 1;
                    echo '<table class="table table-hover" id="sample-table-1">
                            <thead>
                                <tr>
                                    <th class="center">#</th>
                                    <th>Patient Name</th>
                                    <th>Patient Contact Number</th>
                                    <th>Patient Email</th>
                                    <th>Patient Gender</th>
                                    <th>Creation Date</th>
                                    <th>Updation Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>';

                    // Loop through and display the patient records
                    while($row = mysqli_fetch_array($sql)) {
                        echo '<tr>
                                <td class="center">' . $cnt . '.</td>
                                <td class="hidden-xs">' . $row['PatientName'] . '</td>
                                <td>' . decrypt($row['PatientContno']) . '</td>
                                <td>' . decrypt($row['PatientEmail']) . '</td>
                                <td>' . decrypt($row['PatientGender']) . '</td>
                                <td>' . $row['CreationDate'] . '</td>
                                <td>' . ($row['UpdationDate'] ? $row['UpdationDate'] : 'N/A') . '</td>
                                <td>
                                    <a href="edit-patient.php?editid=' . $row['ID'] . '"><i class="fa fa-edit"></i></a> || 
                                    <a href="view-patient.php?viewid=' . $row['ID'] . '"><i class="fa fa-eye"></i></a>
                                </td>
                            </tr>';
                        $cnt++;
                    }

                    echo '</tbody>
                        </table>';
                } else {
                    echo '<p>No records found for this search.</p>';
                }
            }
            ?>
        </div>
    </div>

    <?php include('include/footer.php'); ?>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../assets/js/custom.min.js"></script>

    <script>
        let timeout = <?php echo SESSION_TIMEOUT; ?>;
        let countdown = timeout;

        function updateCountdown() {
            countdown--;
            document.getElementById('countdown').innerText = countdown;

            if (countdown <= 0) {
                alert("Your session has expired. Please log in again.");
                window.location.href = "index.php?session_expired=1";
            }
        }

        setInterval(updateCountdown, 1000);
    </script>
</body>
</html>
