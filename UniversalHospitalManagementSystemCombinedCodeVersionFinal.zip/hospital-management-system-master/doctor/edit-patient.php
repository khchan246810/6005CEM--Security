<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
include('include/session_check_doctor.php');

check_login();
define(constant_name: 'ENCRYPTION_KEY', value: 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

function encryptPatcontact($patcontact) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($patcontact, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}

function decrypt($dataDecrypt) {
    list($iv, $encrypted) = explode('::', base64_decode($dataDecrypt), 2);
    $cipher = "AES-128-CTR";
    return openssl_decrypt($encrypted, $cipher, ENCRYPTION_KEY, 0, $iv);
}
function encryptPatgender($gender) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($gender, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptPatAdd($pataddress) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($pataddress, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptPatAge($patage) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($patage, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptPatMed($medhis) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($medhis, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptPatMail($patemail) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($patemail, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
if(isset($_POST['submit']))
{
	$eid=$_GET['editid'];
	$patname=$_POST['patname'];
	$patcontact=encryptPatcontact($_POST['patcontact']);
	$patemail=encryptPatMail($_POST['patemail']);
	$gender=encryptPatgender($_POST['gender']);
	$pataddress=encryptPatAdd($_POST['pataddress']);
	$patage=encryptPatAge($_POST['patage']);
	$medhis=encryptPatMed($_POST['medhis']);
	$sql=mysqli_query($con,"update tblpatient set PatientName='$patname',PatientContno='$patcontact',PatientEmail='$patemail',PatientGender='$gender',PatientAdd='$pataddress',PatientAge='$patage',PatientMedhis='$medhis' where ID='$eid'");
	if($sql)
	{
		echo "<script>alert('Patient info updated Successfully');</script>";
		header('location:manage-patient.php');

	}
}

if (!defined('SESSION_TIMEOUT')) {
	define('SESSION_TIMEOUT', 300);
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Doctor | Add Patient</title>

	<!-- Bootstrap -->
	<link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<!-- NProgress -->
	<link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	<!-- iCheck -->
	<link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
	<!-- bootstrap-progressbar -->
	<link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
	<!-- JQVMap -->
	<link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
	<!-- bootstrap-daterangepicker -->
	<link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
	<!-- Custom Theme Style -->
	<link href="../assets/css/custom.css" rel="stylesheet">
	<script type="text/javascript">
    function valid() {
        // Validate Contact Number (10 digits)
        const contactNumber = document.edit.patcontact.value.trim();
        const contactRegex = /^\d{10}$/;
        if (!contactRegex.test(contactNumber)) {
            alert("Contact number must be exactly 10 digits.");
            document.edit.patcontact.focus();
            return false;
        }

         // Validate Doctor Name using regex to allow only alphabets and spaces
    const doctorName = document.edit.patname.value.trim();
    const nameRegex = /^[a-zA-Z]+(?:\s[a-zA-Z]+)*$/;
    if (!nameRegex.test(doctorName)) {
        alert("Doctor name should contain only alphabets and spaces.");
        document.edit.patname.focus();
        return false;
    }


        return true;
    }
</script>
</head>
<body class="nav-md">
	<?php
	$page_title = 'Patient | Edit Patient';
	$x_content = true;
	?>
	<?php include('include/header.php');?>

	<div class="row">
		<div class="col-md-12">
			<div class="row margin-top-30">
				<div class="col-lg-8 col-md-12">
					<div class="panel panel-white">
						<div class="panel-heading">
							<h5 class="panel-title">Edit Patient</h5>
						</div>
						<div class="panel-body">
							<form role="form" name="edit" method="post" onsubmit="return valid();">
								<?php
								$eid=$_GET['editid'];
								$ret=mysqli_query($con,"select * from tblpatient where ID='$eid'");
								$cnt=1;
								while ($row=mysqli_fetch_array($ret)) {

									?>
									<div class="form-group">
										<label for="doctorname">
											Patient Name
										</label>
										<input type="text" name="patname" class="form-control"  value="<?php  echo $row['PatientName'];?>" required="true">
									</div>
									<div class="form-group">
										<label for="fess">
											Patient Contact no
										</label>
										<input type="text" name="patcontact" class="form-control"  value="<?php  echo decrypt($row['PatientContno']);?>" required="true" maxlength="10" pattern="[0-9]+">
									</div>
									<div class="form-group">
										<label for="fess">
											Patient Email
										</label>
										<input type="email" id="patemail" name="patemail" class="form-control"  value="<?php  echo decrypt($row['PatientEmail']);?>" readonly='true'>
										<span id="email-availability-status"></span>
									</div>
									<div class="form-group">
										<label class="control-label">Gender: </label>
										<?php  if(decrypt($row['Gender'])=="Female"){ ?>
											<input type="radio" name="gender" id="gender" value="Female" checked="true">Female
											<input type="radio" name="gender" id="gender" value="male">Male
										<?php } else { ?>
											<label>
												<input type="radio" name="gender" id="gender" value="Male" checked="true">Male
												<input type="radio" name="gender" id="gender" value="Female">Female
											</label>
										<?php } ?>
									</div>
									<div class="form-group">
										<label for="address">
											Patient Address
										</label>
										<textarea name="pataddress" class="form-control" required="true"><?php  echo decrypt($row['PatientAdd']);?></textarea>
									</div>
									<div class="form-group">
										<label for="fess">
											Patient Age
										</label>
										<input type="number" name="patage" class="form-control"  value="<?php  echo decrypt($row['PatientAge']);?>" required="true">
									</div>
									<div class="form-group">
										<label for="fess">
											Medical History
										</label>
										<textarea type="text" name="medhis" class="form-control"  placeholder="Enter Patient Medical History(if any)" required="true"><?php  echo decrypt($row['PatientMedhis']);?></textarea>
									</div>
									<div class="form-group">
										<label for="fess">
											Creation Date
										</label>
										<input type="text" class="form-control"  value="<?php  echo $row['CreationDate'];?>" readonly='true'>
									</div>
								<?php } ?>
								<button type="submit" name="submit" id="submit" class="btn btn-o btn-primary">
									Update
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-12 col-md-12">
			<div class="panel panel-white">
			</div>
		</div>
	</div>
	<?php include('include/footer.php');?>
	<!-- jQuery -->
	<script src="../vendors/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap -->
	<script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
	<!-- FastClick -->
	<script src="../vendors/fastclick/lib/fastclick.js"></script>
	<!-- NProgress -->
	<script src="../vendors/nprogress/nprogress.js"></script>
	<!-- Chart.js -->
	<script src="../vendors/Chart.js/dist/Chart.min.js"></script>
	<!-- gauge.js -->
	<script src="../vendors/gauge.js/dist/gauge.min.js"></script>
	<!-- bootstrap-progressbar -->
	<script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
	<!-- iCheck -->
	<script src="../vendors/iCheck/icheck.min.js"></script>
	<!-- Skycons -->
	<script src="../vendors/skycons/skycons.js"></script>
	<!-- Flot -->
	<script src="../vendors/Flot/jquery.flot.js"></script>
	<script src="../vendors/Flot/jquery.flot.pie.js"></script>
	<script src="../vendors/Flot/jquery.flot.time.js"></script>
	<script src="../vendors/Flot/jquery.flot.stack.js"></script>
	<script src="../vendors/Flot/jquery.flot.resize.js"></script>
	<!-- Flot plugins -->
	<script src="../vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
	<script src="../vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
	<script src="../vendors/flot.curvedlines/curvedLines.js"></script>
	<!-- DateJS -->
	<script src="../vendors/DateJS/build/date.js"></script>
	<!-- JQVMap -->
	<script src="../vendors/jqvmap/dist/jquery.vmap.js"></script>
	<script src="../vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
	<script src="../vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
	<!-- bootstrap-daterangepicker -->
	<script src="../vendors/moment/min/moment.min.js"></script>
	<script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
	<!-- Custom Theme Scripts -->
	<script src="../assets/js/custom.min.js"></script>
	<script>
		let timeout = <?php echo SESSION_TIMEOUT; ?>;
		let countdown = timeout;

		function updateCountdown() {
			countdown--;
			document.getElementById('countdown').innerText = countdown;

			if (countdown <= 0) {
				alert("Your session has expired. Please log in again.");
				window.location.href = "index.php?session_expired=1";
			}
		}


		setInterval(updateCountdown, 1000);
	</script>
</body>
</html>