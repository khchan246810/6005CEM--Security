<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
include('include/session_check_doctor.php');

check_login();
define(constant_name: 'ENCRYPTION_KEY', value: 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

function encryptPatcontact($patcontact) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($patcontact, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptPatGender($gender) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($gender, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptPatEmail($patemail) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($patemail, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptPatAdd($pataddress) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($pataddress, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptPatAge($patage) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($patage, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptPatHis($medhis) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($medhis, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
if(isset($_POST['submit']))
{
	$docid=$_SESSION['id'];
	$docname=$_SESSION['doctorName'];
	$patname=$_POST['patname'];
	$patcontact=encryptPatcontact($_POST['patcontact']);
	$patemail=encryptPatEmail($_POST['patemail']);
	$gender=encryptPatGender($_POST['gender']);
	$pataddress=encryptPatAdd($_POST['pataddress']);
	$patage=encryptPatAge($_POST['patage']);
	$medhis=encryptPatHis($_POST['medhis']);
	$sql=mysqli_query($con,"insert into tblpatient(Docid,doctorName, PatientName,PatientContno,PatientEmail,PatientGender,PatientAdd,PatientAge,PatientMedhis) values('$docid','$docname','$patname','$patcontact','$patemail','$gender','$pataddress','$patage','$medhis')");
	if($sql)
	{
		echo "<script>alert('Patient info added Successfully');</script>";
		header('location:add-patient.php');

	}
}
if (!defined('SESSION_TIMEOUT')) {
	define('SESSION_TIMEOUT', 300);
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Doctor | Add Patient </title>

	<!-- Bootstrap -->
	<link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<!-- NProgress -->
	<link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
	<!-- iCheck -->
	<link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
	<!-- bootstrap-progressbar -->
	<link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
	<!-- JQVMap -->
	<link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
	<!-- bootstrap-daterangepicker -->
	<link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
	<!-- Custom Theme Style -->
	<link href="../assets/css/custom.css" rel="stylesheet">
	<script type="text/javascript">
    function valid() {
        // Validate Patient Name (only letters and spaces allowed)
        const patName = document.adddoc.patname.value.trim();
        const nameRegex = /^[a-zA-Z]+(?:\s[a-zA-Z]+)*$/;  // Regex for name with letters and spaces
        if (!nameRegex.test(patName)) {
            alert("Patient name must contain only letters and spaces.");
            document.adddoc.patname.focus();
            return false;
        }

        // Validate Contact Number (10 digits)
        const contactNumber = document.adddoc.patcontact.value.trim();
        const contactRegex = /^\d{10}$/;
        if (!contactRegex.test(contactNumber)) {
            alert("Contact number must be exactly 10 digits.");
            document.adddoc.patcontact.focus();
            return false;
        }

        return true;
    }
</script>


	<script>
		function userAvailability() {
			$("#loaderIcon").show();
			jQuery.ajax({
				url: "check_availability.php",
				data:'email='+$("#patemail").val(),
				type: "POST",
				success:function(data){
					$("#user-availability-status1").html(data);
					$("#loaderIcon").hide();
				},
				error:function (){}
			});
		}
	</script>
</head>
<body class="nav-md">
	<?php
	$page_title = 'Patient | Add Patient';
	$x_content = true;
	?>
	<?php include('include/header.php');?>

	<div class="row">
		<div class="col-md-12">
			<div class="row margin-top-30">
				<div class="col-lg-8 col-md-12">
					<div class="panel panel-white">
					<form role="form" name="adddoc" method="post" onSubmit="return valid();">

						<div class="panel-heading">
							<h5 class="panel-title">Add Patient (After visit the doctor during the appointment)</h5>
						</div>
						<div class="panel-body">
							<form role="form" name="" method="post">

								<div class="form-group">
									<label for="doctorname">
										Patient Name
									</label>
									<input type="text" name="patname" class="form-control"  placeholder="Enter Patient Name" required="true">
								</div>
								<!-- Doctor Contact no -->
    <div class="form-group">
        <label for="fess">Doctor Contact no</label>
        <input type="text" name="patcontact" class="form-control" placeholder="Enter Patient Contact no in '0000000000'" required="true">
    </div>

								<div class="form-group">
									<label for="fess">
										Patient Email
									</label>
									<input type="email" id="patemail" name="patemail" class="form-control"  placeholder="Enter Patient Email id" required="true" onBlur="userAvailability()">
									<span id="user-availability-status1" style="font-size:12px;"></span>
								</div>
								<div class="form-group">
									<label class="block">
										Gender
									</label>
									<div class="clip-radio radio-primary">
										<input type="radio" id="rg-female" name="gender" value="female" >
										<label for="rg-female">
											Female
										</label>
										<input type="radio" id="rg-male" name="gender" value="male">
										<label for="rg-male">
											Male
										</label>
									</div>
								</div>
								<div class="form-group">
									<label for="address">
										Patient Address
									</label>
									<textarea name="pataddress" class="form-control"  placeholder="Enter Patient Address" required="true"></textarea>
								</div>
								<div class="form-group">
									<label for="fess">
										Patient Age
									</label>
									<input type="number" name="patage" class="form-control"  placeholder="Enter Patient Age" required="true">
								</div>
								<div class="form-group">
									<label for="fess">
										Medical History
									</label>
									<textarea type="text" name="medhis" class="form-control"  placeholder="Enter Patient Medical History(if any)" required="true"></textarea>
								</div>

								<button type="submit" name="submit" id="submit" class="btn btn-o btn-primary">
									Add
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-lg-12 col-md-12">
			<div class="panel panel-white">
			</div>
		</div>
	</div>
	<?php include('include/footer.php');?>
	<!-- jQuery -->
	<script src="../vendors/jquery/dist/jquery.min.js"></script>
	<!-- Bootstrap -->
	<script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
	<!-- FastClick -->
	<script src="../vendors/fastclick/lib/fastclick.js"></script>
	<!-- NProgress -->
	<script src="../vendors/nprogress/nprogress.js"></script>
	<!-- Chart.js -->
	<script src="../vendors/Chart.js/dist/Chart.min.js"></script>
	<!-- gauge.js -->
	<script src="../vendors/gauge.js/dist/gauge.min.js"></script>
	<!-- bootstrap-progressbar -->
	<script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
	<!-- iCheck -->
	<script src="../vendors/iCheck/icheck.min.js"></script>
	<!-- Skycons -->
	<script src="../vendors/skycons/skycons.js"></script>
	<!-- Flot -->
	<script src="../vendors/Flot/jquery.flot.js"></script>
	<script src="../vendors/Flot/jquery.flot.pie.js"></script>
	<script src="../vendors/Flot/jquery.flot.time.js"></script>
	<script src="../vendors/Flot/jquery.flot.stack.js"></script>
	<script src="../vendors/Flot/jquery.flot.resize.js"></script>
	<!-- Flot plugins -->
	<script src="../vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
	<script src="../vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
	<script src="../vendors/flot.curvedlines/curvedLines.js"></script>
	<!-- DateJS -->
	<script src="../vendors/DateJS/build/date.js"></script>
	<!-- JQVMap -->
	<script src="../vendors/jqvmap/dist/jquery.vmap.js"></script>
	<script src="../vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
	<script src="../vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
	<!-- bootstrap-daterangepicker -->
	<script src="../vendors/moment/min/moment.min.js"></script>
	<script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
	<!-- Custom Theme Scripts -->
	<script src="../assets/js/custom.min.js"></script>
	<script>
		let timeout = <?php echo SESSION_TIMEOUT; ?>;
		let countdown = timeout;

		function updateCountdown() {
			countdown--;
			document.getElementById('countdown').innerText = countdown;

			if (countdown <= 0) {
				alert("Your session has expired. Please log in again.");
				window.location.href = "index.php?session_expired=1";
			}
		}


		setInterval(updateCountdown, 1000);
	</script>
</body>
</html>