<?php 
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
include ('include/session_check_admin.php');

check_login();

if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 300);
}

define('ENCRYPTION_KEY', 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

function decrypt($dataDecrypt) {
    list($iv, $encrypted) = explode('::', base64_decode($dataDecrypt), 2);
    $cipher = "AES-128-CTR";
    return openssl_decrypt($encrypted, $cipher, ENCRYPTION_KEY, 0, $iv);
}

// Function to sanitize input
function sanitize_input($input) {
    // Remove any apostrophes and other special characters
    $input = str_replace("'", "", $input);  // Remove apostrophes
    $input = str_replace('"', "", $input);  // Remove double quotes
    $input = preg_replace('/[^A-Za-z0-9 ]/', '', $input); // Remove all other special characters
    return $input;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin | View Patients</title>
    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../assets/css/custom.min.css" rel="stylesheet">
</head>
<body class="nav-md">
    <?php
    $page_title = 'Admin | View Patients';
    $x_content = true;
    ?>
    <?php include('include/header.php');?>

    <div class="row">
        <div class="col-md-12">
            <form role="form" method="post" name="search">
                <div class="form-group">
                    <label for="doctorname">
                        Search by Name/Mobile No.
                    </label>
                    <input type="text" name="searchdata" id="searchdata" class="form-control" value="" required='true'>
                </div>
                <button type="submit" name="search" id="submit" class="btn btn-o btn-primary">
                    Search
                </button>
            </form>

            <?php
            if(isset($_POST['search']))
            {
                // Sanitize the search input
                $sdata = sanitize_input($_POST['searchdata']);
                ?>
                <h4 align="center">Result against "<?php echo $sdata;?>" keyword </h4>
                <table class="table table-hover" id="sample-table-1">
                    <thead>
                        <tr>
                            <th class="center">#</th>
                            <th>Patient Name</th>
                            <th>Patient Contact Number</th>
                            <th>Patient Gender </th>
                            <th>Creation Date </th>
                            <th>Updation Date </th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Prepare the SQL query with placeholders
                        $sql = mysqli_prepare($con, "SELECT * FROM tblpatient WHERE PatientName LIKE ? OR PatientContno LIKE ?");
                        
                        // Sanitize the search data for SQL
                        $search_pattern = "%" . $sdata . "%"; // Add % for LIKE search
                        
                        // Bind the sanitized parameters to the SQL query
                        mysqli_stmt_bind_param($sql, 'ss', $search_pattern, $search_pattern);
                        
                        // Execute the query
                        mysqli_stmt_execute($sql);
                        
                        // Get the result
                        $result = mysqli_stmt_get_result($sql);
                        $num = mysqli_num_rows($result);
                        
                        if($num > 0){
                            $cnt = 1;
                            while($row = mysqli_fetch_array($result)) {
                                ?>
                                <tr>
                                    <td class="center"><?php echo $cnt;?>.</td>
                                    <td class="hidden-xs"><?php echo htmlspecialchars($row['PatientName']); ?></td>
                                    <td><?php echo decrypt($row['PatientContno']);?></td>
                                    <td><?php echo decrypt($row['PatientGender']);?></td>
                                    <td><?php echo $row['CreationDate'];?></td>
                                    <td><?php echo $row['UpdationDate'];?></td>
                                    <td>
                                        <a href="view-patient.php?viewid=<?php echo $row['ID'];?>"><i class="fa fa-eye"></i></a>
                                    </td>
                                </tr>
                                <?php
                                $cnt++;
                            } 
                        } else { 
                            ?>
                            <tr>
                                <td colspan="8"> No record found against this search</td>
                            </tr>
                        <?php } 
                    } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php include('include/footer.php');?>
    
    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../assets/js/custom.min.js"></script>
</body>
</html>
