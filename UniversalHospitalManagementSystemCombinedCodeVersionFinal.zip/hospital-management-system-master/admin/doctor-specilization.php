<?php 
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
include ('include/session_check_admin.php');

check_login();
define('ENCRYPTION_KEY', 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

// Function to sanitize and block unwanted characters like apostrophes
function sanitize_input($input) {
    // Remove any apostrophes and other special characters
    $input = str_replace("'", "", $input);  // Remove apostrophes
    $input = str_replace('"', "", $input);  // Remove double quotes
    $input = preg_replace('/[^A-Za-z0-9 ]/', '', $input); // Remove all other special characters
    return $input;
}

// Add Doctor Specialization
if (isset($_POST['submit'])) {
    $docspecialization = trim($_POST['doctorspecilization']); // Trim extra spaces

    // Check if the input is not empty
    if (!empty($docspecialization)) {
        // Sanitize input to remove apostrophes and special characters
        $docspecialization = sanitize_input($docspecialization);

        // Use prepared statements to safely insert into the database
        $stmt = $con->prepare("INSERT INTO doctorspecilization (specilization) VALUES (?)");
        $stmt->bind_param("s", $docspecialization); // "s" means the input is a string
        
        // Execute the query
        if ($stmt->execute()) {
            $_SESSION['msg'] = "Doctor Specialization added successfully !!";
        } else {
            $_SESSION['msg'] = "Error: " . $stmt->error; // Capture and display error
        }
        
        $stmt->close(); // Close the statement
    } else {
        $_SESSION['msg'] = "Specialization cannot be empty!"; // Handle empty input
    }
}

// Delete Doctor Specialization
if (isset($_GET['del']) && $_GET['del'] == 'delete') {
    if (isset($_GET['id']) && is_numeric($_GET['id'])) {
        $id = $_GET['id'];

        // Prepare the delete query with prepared statements
        $stmt = $con->prepare("DELETE FROM doctorspecilization WHERE id = ?");
        $stmt->bind_param("i", $id); // "i" means the input is an integer
        
        // Execute the query
        if ($stmt->execute()) {
            $_SESSION['msg'] = "Doctor Specialization deleted successfully!";
        } else {
            $_SESSION['msg'] = "Error: " . $stmt->error; // Capture and display error
        }

        $stmt->close(); // Close the statement
    }
}

if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 300);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin | Doctor Specialization</title>
    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../assets/css/custom.min.css" rel="stylesheet">
</head>
<body class="nav-md">
    <?php
    $page_title = 'Admin | Add Doctor Specialization';
    $x_content = true;
    ?>
    <?php include('include/header.php');?>

    <div class="row">
        <div class="col-md-12">
            <div class="row margin-top-30">
                <div class="col-lg-6 col-md-12">
                    <div class="panel panel-white">
                        <div class="panel-heading">
                            <h5 class="panel-title">Doctor Specialization</h5>
                        </div>
                        <div class="panel-body">
                            <p style="color:red;"><?php echo htmlentities($_SESSION['msg']);?></p>
                            <?php echo htmlentities($_SESSION['msg'] = "");?>
                            <form role="form" name="dcotorspcl" method="post">
                                <div class="form-group">
                                    <label for="doctorspecilization">Doctor Specialization</label>
                                    <input id="doctorspecilization" type="text" name="doctorspecilization" class="form-control" required="required" placeholder="Enter Doctor Specialization">
                                </div>
                                <button type="submit" name="submit" class="btn btn-o btn-primary">
                                    Submit
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-12 col-md-12">
            <div class="panel panel-white">
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 mt-5">
            <h5 class="over-title">Manage <span class="text-bold">Doctor Specialization</span></h5>
            <table class="table table-hover" id="sample-table-1">
                <thead>
                    <tr>
                        <th class="center">#</th>
                        <th>Specialization</th>
                        <th class="hidden-xs">Creation Date</th>
                        <th>Updation Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = mysqli_query($con, "SELECT * FROM doctorspecilization");
                    $cnt = 1;
                    while ($row = mysqli_fetch_array($sql)) {
                        ?>
                        <tr>
                            <td class="center"><?php echo $cnt;?>.</td>
                            <td class="hidden-xs"><?php echo $row['specilization'];?></td>
                            <td><?php echo $row['creationDate'];?></td>
                            <td><?php echo $row['updationDate'];?></td>
                            <td>
                                <div class="visible-md visible-lg hidden-sm hidden-xs">
                                    <a href="edit-doctor-specialization.php?id=<?php echo $row['id'];?>" class="btn btn-transparent btn-xs" tooltip-placement="top" tooltip="Edit"><i class="fa fa-pencil"></i></a>
                                    <a href="doctor-specilization.php?id=<?php echo $row['id']?>&del=delete" onClick="return confirm('Are you sure you want to delete?')" class="btn btn-transparent btn-xs tooltips" tooltip-placement="top" tooltip="Remove"><i class="fa fa-times fa fa-white"></i></a>
                                </div>
                            </td>
                        </tr>
                    <?php
                    $cnt = $cnt + 1;
                    } ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php include('include/footer.php');?>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../assets/js/custom.min.js"></script>

    <script>
        let timeout = <?php echo SESSION_TIMEOUT; ?>;
        let countdown = timeout;

        function updateCountdown() {
            countdown--;
            document.getElementById('countdown').innerText = countdown;

            if (countdown <= 0) {
                alert("Your session has expired. Please log in again.");
                window.location.href = "admin/index.php?session_expired=1";
            }
        }

        setInterval(updateCountdown, 1000);
    </script>
</body>
</html>
