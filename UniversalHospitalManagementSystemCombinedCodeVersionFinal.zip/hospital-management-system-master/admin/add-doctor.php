<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
include('include/session_check_admin.php');

check_login();
define('ENCRYPTION_KEY', 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT); // Hash the password using bcrypt
}
// Function to validate password requirements
function validatePassword($password) {
    // Ensure password is at least 8 characters long
    if (strlen($password) < 8) {
        return "Password must be at least 8 characters long.";
    }
    // Check if password contains at least one uppercase letter
    if (!preg_match('/[A-Z]/', $password)) {
        return "Password must contain at least one uppercase letter.";
    }
    // Check if password contains at least one number
    if (!preg_match('/\d/', $password)) {
        return "Password must contain at least one number.";
    }
    // Check if password contains at least one special character
    if (!preg_match('/[\W_]/', $password)) {
        return "Password must contain at least one special character.";
    }
    return true;
}
function encryptFees($docfees) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($docfees, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}

function encryptContact($doccontactno) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($doccontactno, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}

function decrypt($dataDecrypt) {
    list($iv, $encrypted) = explode('::', base64_decode($dataDecrypt), 2);
    $cipher = "AES-128-CTR";
    return openssl_decrypt($encrypted, $cipher, ENCRYPTION_KEY, 0, $iv);
}

function encryptAddress($docaddress) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($docaddress, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}


if (isset($_POST['submit'])) {
    // Sanitize inputs
    $docspecialization = mysqli_real_escape_string($con, $_POST['Doctorspecialization']);
    $docname = mysqli_real_escape_string($con, $_POST['docname']);
    $docaddress = encryptAddress(mysqli_real_escape_string($con, $_POST['clinicaddress']));
    $docfees = encryptFees(mysqli_real_escape_string($con, $_POST['docfees']));
    $doccontactno = encryptContact(mysqli_real_escape_string($con, $_POST['doccontact']));
    $docemail = mysqli_real_escape_string($con, $_POST['docemail']);
    $password = mysqli_real_escape_string($con, $_POST['npass']);

    // Validate the password
    $passwordValidation = validatePassword($password);
    if ($passwordValidation !== true) {
        echo "<script>alert('$passwordValidation');</script>";
        return;
    }

    // Hash the password
    $hashedPassword = hashPassword($password);

    // Insert doctor info into the database
    $sql = mysqli_query($con, "INSERT INTO doctors(specilization, doctorName, address, docFees, contactno, docEmail, password) 
        VALUES('$docspecialization', '$docname', '$docaddress', '$docfees', '$doccontactno', '$docemail', '$hashedPassword')");
    
    if ($sql) {
        echo "<script>alert('Doctor info added successfully');</script>";
        echo "<script>window.location.href = 'manage-doctors.php'</script>";
    }
}

if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 300);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin | Add Doctor</title>

    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../assets/css/custom.min.css" rel="stylesheet">
    <script type="text/javascript">
    function valid() {
        // Password and Confirm Password check
        if (document.adddoc.npass.value != document.adddoc.cfpass.value) {
            alert("Password and Confirm Password do not match!");
            document.adddoc.cfpass.focus();
            return false;
        }

        // Trim spaces from both sides of the password
        const password = document.adddoc.npass.value.trim();

        // Validate password length (minimum 8 characters), at least one uppercase, one number, and one special character
        const passwordFeedback = document.getElementById("password-feedback");

        // Password validation regex
        const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;

        if (!passwordRegex.test(password)) {
            passwordFeedback.textContent = "Password must be at least 8 characters long, include at least one uppercase letter, one number, and one special character.";
            passwordFeedback.style.color = 'red';
            return false;
        } else {
            passwordFeedback.textContent = "Password is valid.";
            passwordFeedback.style.color = 'green';
        }

        // Validate Contact Number (10 digits)
        const contactNumber = document.adddoc.doccontact.value.trim();
        const contactRegex = /^\d{10}$/;
        if (!contactRegex.test(contactNumber)) {
            alert("Contact number must be exactly 10 digits.");
            document.adddoc.doccontact.focus();
            return false;
        }

        return true;
    }
    </script>



    <script>
        function checkemailAvailability() {
            $("#loaderIcon").show();
            jQuery.ajax({
                url: "check_availability.php",
                data: 'emailid=' + $("#docemail").val(),
                type: "POST",
                success: function (data) {
                    $("#email-availability-status").html(data);
                    $("#loaderIcon").hide();
                },
                error: function () {}
            });
        }
    </script>
</head>
<body class="nav-md">
    <?php
    $page_title = 'Add Doctor';
    $x_content = true;
    ?>
    <?php include('include/header.php');?>

    <div class="row">
        <div class="col-md-12">

            <div class="row margin-top-30">
                <div class="col-lg-8 col-md-12">
                    <div class="panel panel-white">
                        <div class="panel-body">

						<form role="form" name="adddoc" method="post" onSubmit="return valid();">
    <!-- Doctor Specialization -->
    <div class="form-group">
        <label for="DoctorSpecialization">Doctor Specialization</label>
        <select name="Doctorspecialization" class="form-control" required="true">
            <option value="">Select Specialization</option>
            <?php
            $ret = mysqli_query($con, "SELECT * FROM doctorspecilization");
            while ($row = mysqli_fetch_array($ret)) {
                ?>
                <option value="<?php echo $row['specilization'];?>">
                    <?php echo $row['specilization'];?>
                </option>
            <?php } ?>
        </select>
    </div>

    <!-- Doctor Name -->
    <div class="form-group">
        <label for="doctorname">Doctor Name</label>
        <input type="text" name="docname" class="form-control" placeholder="Enter Doctor Name" required="true">
    </div>

    <!-- Doctor Clinic Address -->
    <div class="form-group">
        <label for="address">Doctor Clinic Address</label>
        <textarea name="clinicaddress" class="form-control" placeholder="Enter Doctor Clinic Address" required="true"></textarea>
    </div>

   <!-- Doctor Consultancy Fees -->
<div class="form-group">
    <label for="fess">Doctor Consultancy Fees</label>
    <input type="number" name="docfees" class="form-control" placeholder="Enter Doctor Consultancy Fees" required="true">
</div>


    <!-- Doctor Contact no -->
    <div class="form-group">
        <label for="fess">Doctor Contact no</label>
        <input type="text" name="doccontact" class="form-control" placeholder="Enter Doctor Contact no in '0000000000'" required="true">
    </div>

    <!-- Doctor Email -->
    <div class="form-group">
        <label for="fess">Doctor Email</label>
        <input type="email" id="docemail" name="docemail" class="form-control" placeholder="Enter Doctor Email id" required="true" onBlur="checkemailAvailability()">
        <span id="email-availability-status"></span>
    </div>

    <!-- Password -->
    <div class="form-group">
        <label for="exampleInputPassword1">Password</label>
        <input type="password" name="npass" class="form-control" placeholder="New Password" required="required">
        <div id="password-feedback"></div>
    </div>

    <!-- Confirm Password -->
    <div class="form-group">
        <label for="exampleInputPassword2">Confirm Password</label>
        <input type="password" name="cfpass" class="form-control" placeholder="Confirm Password" required="required">
    </div>

    <!-- Submit Button -->
    <button type="submit" name="submit" id="submit" class="btn btn-o btn-primary">Submit</button>
</form>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- start: FOOTER -->
    <?php include('include/footer.php');?>

    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="../vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="../vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="../vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="../vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="../vendors/Flot/jquery.flot.js"></script>
    <script src="../vendors/Flot/jquery.flot.pie.js"></script>
    <script src="../vendors/Flot/jquery.flot.time.js"></script>
    <script src="../vendors/Flot/jquery.flot.stack.js"></script>
    <script src="../vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="../vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="../vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="../vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="../vendors/DateJS/build/date.js"></script>
    <!-- JQVMap -->
    <script src="../vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="../vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="../vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="../vendors/moment/min/moment.min.js"></script>
    <script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../assets/js/custom.min.js"></script>

</body>
</html>
