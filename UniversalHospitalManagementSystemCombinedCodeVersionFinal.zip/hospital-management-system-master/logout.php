<?php
session_start();
include('include/config.php');

if(isset($_SESSION['id'])) {
    // Set timezone and current logout time
    date_default_timezone_set('Asia/Kuala_Lumpur');
    $ldate = date('Y-m-d H:i:s', time());

    // Get the last login entry for the current user (logged in by their session ID)
    $uid = $_SESSION['id'];

    // Update the latest user log entry for this user
    $updateLogoutQuery = "UPDATE userlog SET logout = '$ldate' WHERE uid = '$uid' AND logout IS NULL ORDER BY loginTime DESC LIMIT 1";
    mysqli_query($con, $updateLogoutQuery);

    // Clear the session data
    session_unset();
    //session_destroy();

    // Set a success message
    $_SESSION['errmsg'] = "You have successfully logged out.";
}
?>

<script language="javascript">
    document.location = "index.php";
</script>
