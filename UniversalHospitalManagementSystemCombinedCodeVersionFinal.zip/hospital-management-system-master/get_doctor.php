<?php
include('include/config.php');
define(constant_name: 'ENCRYPTION_KEY', value: 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

  function decrypt($dataDecrypt) {
    list($iv, $encrypted) = explode('::', base64_decode($dataDecrypt), 2);
    $cipher = "AES-128-CTR";
    return openssl_decrypt($encrypted, $cipher, ENCRYPTION_KEY, 0, $iv);
}

// Fetch doctor name based on selected doctor ID
if (isset($_POST['doctorId'])) {
    $doctorId = $_POST['doctorId'];
    $query = mysqli_query($con, "SELECT doctorName FROM doctors WHERE id='$doctorId'");
    if ($row = mysqli_fetch_array($query)) {
        echo $row['doctorName'];  // Return the doctor's name
    }
}


if(!empty($_POST["specilizationid"])) 
{

 $sql=mysqli_query($con,"select doctorName,id from doctors where specilization='".$_POST['specilizationid']."'");?>
 <option selected="selected">Select Doctor </option>
 <?php
 while($row=mysqli_fetch_array($sql))
 	{?>
  <option value="<?php echo htmlentities($row['id']); ?>"><?php echo htmlentities($row['doctorName']); ?></option>
  <?php
}
}


if(!empty($_POST["doctor"])) 
{

 $sql=mysqli_query($con,"select docFees from doctors where id='".$_POST['doctor']."'");
 while($row=mysqli_fetch_array($sql))
 	{?>
 <option value="<?php echo decrypt($row['docFees']); ?>"><?php echo decrypt($row['docFees']); ?></option>
  <?php
}
}

?>

