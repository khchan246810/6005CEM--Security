<?php 
session_start();
include('include/config.php');
include('include/checklogin.php');
include ('include/session_check_patient.php');

check_login();

define('ENCRYPTION_KEY', 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

// Encryption and Decryption functions
function decrypt($dataDecrypt) {
    list($iv, $encrypted) = explode('::', base64_decode($dataDecrypt), 2);
    $cipher = "AES-128-CTR";
    return openssl_decrypt($encrypted, $cipher, ENCRYPTION_KEY, 0, $iv);
}

function encryptAddress($address) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher));
    $encrypted = openssl_encrypt($address, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted);
}

function encryptCity($city) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher));
    $encrypted = openssl_encrypt($city, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted);
}

function encryptGend($gender) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher));
    $encrypted = openssl_encrypt($gender, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted);
}

function encryptMail($email) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher));
    $encrypted = openssl_encrypt($email, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted);
}

// Session timeout
if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 300);
}

if(isset($_POST['submit'])) {
    $fname = $_POST['fname'];
    $address = encryptAddress($_POST['address']);
    $city = encryptCity($_POST['city']);
    $gender = encryptGend($_POST['gender']);
    $email = encryptMail($_POST['uemail']);

    $sql = mysqli_query($con, "UPDATE users SET fullName='$fname', address='$address', city='$city', gender='$gender', email='$email' WHERE id='".$_SESSION['id']."'");
    if($sql) {
        $msg = "Your Profile updated successfully.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>User | Edit Profile</title>
    <!-- Bootstrap CSS -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="assets/css/custom.min.css" rel="stylesheet">

    <script type="text/javascript">
        function valid() {
            // Validate User Name to contain only alphabets and spaces
            const userName = document.edit.fname.value.trim();
            const nameRegex = /^[a-zA-Z\s]+$/;
            if (!nameRegex.test(userName)) {
                alert("Name should contain only alphabets and spaces.");
                document.edit.fname.focus();
                return false;
            }
            return true;
        }
    </script>
</head>
<body class="nav-md">
    <?php include('include/header.php'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="row margin-top-30">
                <div class="col-lg-8 col-md-12">
                    <div class="panel panel-white">
                        <div class="panel-heading">
                            <h5 class="panel-title">Edit Profile</h5>
                        </div>
                        <div class="panel-body">
                            <?php
                            $sql = mysqli_query($con, "SELECT * FROM users WHERE id='".$_SESSION['id']."'");
                            while($data = mysqli_fetch_array($sql)) {
                            ?>
                                <h4><?php echo htmlentities($data['fullName']); ?>'s Profile</h4>
                                <p><b>Profile Reg. Date: </b><?php echo htmlentities($data['regDate']); ?></p>
                                <?php if($data['updationDate']) { ?>
                                    <p><b>Profile Last Updated: </b><?php echo htmlentities($data['updationDate']); ?></p>
                                <?php } ?>
                                <hr />
                                <form role="form" name="edit" method="post" onsubmit="return valid();">
                                    <div class="form-group">
                                        <label for="fname">User Name</label>
                                        <input type="text" name="fname" class="form-control" value="<?php echo htmlentities($data['fullName']); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="address">Address</label>
                                        <textarea name="address" class="form-control" required><?php echo decrypt($data['address']); ?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="city">City</label>
                                        <input type="text" name="city" class="form-control" value="<?php echo decrypt($data['city']); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="gender">Gender</label>
                                        <select name="gender" class="form-control" required>
                                            <option value="<?php echo decrypt($data['gender']); ?>"><?php echo decrypt($data['gender']); ?></option>
                                            <option value="male">Male</option>
                                            <option value="female">Female</option>
                                            <option value="other">Other</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="uemail">User Email</label>
                                        <input type="email" name="uemail" class="form-control" value="<?php echo decrypt($data['email']); ?>" required>
                                    </div>
                                    <button type="submit" name="submit" class="btn btn-primary">Update</button>
                                </form>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include('include/footer.php'); ?>

    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="assets/js/custom.min.js"></script>
</body>
</html>
