<?php
session_start();
//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
include ('include/session_check_patient.php');

check_login();

define(constant_name: 'ENCRYPTION_KEY', value: 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

function decrypt($dataDecrypt) {
    list($iv, $encrypted) = explode('::', base64_decode($dataDecrypt), 2);
    $cipher = "AES-128-CTR";
    return openssl_decrypt($encrypted, $cipher, ENCRYPTION_KEY, 0, $iv);
}
function encryptAddress($address) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($address, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptCity($city) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($city, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}

function encryptGend($gender) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($gender, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptMail($email) {
    $cipher = "AES-128-CTR";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
    $encrypted = openssl_encrypt($email, $cipher, ENCRYPTION_KEY, 0, $iv);
    return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
if(isset($_POST['submit']))
{
	$fname=$_POST['fname'];
	$address=encryptAddress($_POST['address']);
	$city=encryptCity($_POST['city']);
	$gender=encryptGend($_POST['gender']);
	$email=encryptMail($_POST['uemail']);

	$sql=mysqli_query($con,"Update users set fullName='$fname',address='$address',city='$city',gender='$gender', email='$email' where id='".$_SESSION['id']."'");
	if($sql)
	{
		$msg="Your Profile updated Successfully";
	}
}
if (!defined('SESSION_TIMEOUT')) {
	define('SESSION_TIMEOUT', 300);
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>User | Edit Profile</title>
	<!-- Bootstrap -->
	<link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Awesome -->
	<link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
	<!-- NProgress -->
	<link href="vendors/nprogress/nprogress.css" rel="stylesheet">
	<!-- iCheck -->
	<link href="vendors/iCheck/skins/flat/green.css" rel="stylesheet">
	<!-- bootstrap-progressbar -->
	<link href="vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
	<!-- JQVMap -->
	<link href="vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
	<!-- bootstrap-daterangepicker -->
	<link href="vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
	<!-- Custom Theme Style -->
	<link href="assets/css/custom.min.css" rel="stylesheet">
</head>
<body class="nav-md">
	<?php
	$page_title = 'User | Edit Profile';
	$x_content = true;
	?>
	<?php include('include/header.php');?>
	<div class="row">
		<div class="col-md-12">
				<div class="row margin-top-30">
					<div class="col-lg-8 col-md-12">
						<div class="panel panel-white">
							<div class="panel-heading">
								<h5 class="panel-title">Edit Profile</h5>
							</div>
							<div class="panel-body">
								<?php
								$sql=mysqli_query($con,"select * from users where id='".$_SESSION['id']."'");
								while($data=mysqli_fetch_array($sql))
								{
									?>
									<h4><?php echo htmlentities($data['fullName']);?>'s Profile</h4>
									<p><b>Profile Reg. Date: </b><?php echo htmlentities($data['regDate']);?></p>
									<?php if($data['updationDate']){?>
										<p><b>Profile Last Updation Date: </b><?php echo htmlentities($data['updationDate']);?></p>
									<?php } ?>
									<hr />													<form role="form" name="edit" method="post">
										<div class="form-group">
											<label for="fname">
												User Name
											</label>
											<input type="text" name="fname" class="form-control" value="<?php echo htmlentities($data['fullName']);?>" >
										</div>
										<div class="form-group">
											<label for="address">
												Address
											</label>
											<textarea name="address" class="form-control"><?php echo decrypt($data['address']);?></textarea>
										</div>
										<div class="form-group">
											<label for="city">
												City
											</label>
											<input type="text" name="city" class="form-control" required="required"  value="<?php echo decrypt($data['city']);?>" >
										</div>
										<div class="form-group">
											<label for="gender">
												Gender
											</label>
											<select name="gender" class="form-control" required="required" >
												<option value="<?php echo decrypt($data['gender']);?>"><?php echo decrypt($data['gender']);?></option>
												<option value="male">male</option>
												<option value="female">female</option>
												<option value="other">Other</option>
											</select>
										</div>
										<div class="form-group">
											<label for="fess">
												User Email
											</label>
											<input type="email" name="uemail" class="form-control"  value="<?php echo decrypt($data['email']);?>">
										</div>
										<button type="submit" name="submit" class="btn btn-o btn-primary">
											Update
										</button>
									</form>
								<?php } ?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-12 col-md-12">
				<div class="panel panel-white">
				</div>
			</div>
		</div>
		<?php include('include/footer.php');?>
		<!-- jQuery -->
		<script src="vendors/jquery/dist/jquery.min.js"></script>
		<!-- Bootstrap -->
		<script src="vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
		<!-- FastClick -->
		<script src="vendors/fastclick/lib/fastclick.js"></script>
		<!-- NProgress -->
		<script src="vendors/nprogress/nprogress.js"></script>
		<!-- Chart.js -->
		<script src="vendors/Chart.js/dist/Chart.min.js"></script>
		<!-- gauge.js -->
		<script src="vendors/gauge.js/dist/gauge.min.js"></script>
		<!-- bootstrap-progressbar -->
		<script src="vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
		<!-- iCheck -->
		<script src="vendors/iCheck/icheck.min.js"></script>
		<!-- Skycons -->
		<script src="vendors/skycons/skycons.js"></script>
		<!-- Flot -->
		<script src="vendors/Flot/jquery.flot.js"></script>
		<script src="vendors/Flot/jquery.flot.pie.js"></script>
		<script src="vendors/Flot/jquery.flot.time.js"></script>
		<script src="vendors/Flot/jquery.flot.stack.js"></script>
		<script src="vendors/Flot/jquery.flot.resize.js"></script>
		<!-- Flot plugins -->
		<script src="vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
		<script src="vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
		<script src="vendors/flot.curvedlines/curvedLines.js"></script>
		<!-- DateJS -->
		<script src="vendors/DateJS/build/date.js"></script>
		<!-- JQVMap -->
		<script src="vendors/jqvmap/dist/jquery.vmap.js"></script>
		<script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
		<script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
		<!-- bootstrap-daterangepicker -->
		<script src="vendors/moment/min/moment.min.js"></script>
		<script src="vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
		<!-- Custom Theme Scripts -->
		<script src="assets/js/custom.min.js"></script>
		<script>
		let timeout = <?php echo SESSION_TIMEOUT; ?>;
		let countdown = timeout;

		function updateCountdown() {
			countdown--;
			document.getElementById('countdown').innerText = countdown;

			if (countdown <= 0) {
				alert("Your session has expired. Please log in again.");
				window.location.href = "index.php?session_expired=1";
			}
		}

		
		setInterval(updateCountdown, 1000);
	</script>
	</body>