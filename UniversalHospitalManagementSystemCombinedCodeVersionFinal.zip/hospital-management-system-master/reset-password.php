<?php
session_start();
error_reporting(0);
include("include/config.php");
include('include/session_check_patient.php'); // Assuming this checks if the user is logged in.

// Code for resetting the password
if (isset($_POST['submit'])) {
    // Getting user email from session (assuming email is stored in session)
    $name = $_SESSION['name']; 

    $newpassword = $_POST['password']; // New password from the form

    // Validate the new password (at least 8 characters, 1 uppercase, 1 digit, 1 special character)
    if (!preg_match('/^(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $newpassword)) {
        $_SESSION['msg1'] = "New password must be at least 8 characters long, include at least one uppercase letter, one number, and one special character.";
    } elseif ($_POST['password'] != $_POST['password_again']) {
        $_SESSION['msg1'] = "Password and Confirm Password do not match!";
    } else {
        // Hash the new password using PASSWORD_BCRYPT
        $hashedPassword = password_hash($newpassword, PASSWORD_BCRYPT);
        
        // Update the password in the database based on email
        $query = mysqli_query($con, "UPDATE users SET password='$hashedPassword' WHERE fullName='$name'");

        if ($query) {
            $_SESSION['msg1'] = "Password Reset Successfully!";
            echo "<script>alert('Password successfully updated.');</script>";
            echo "<script>window.location.href ='index.php'</script>"; // Redirect to login page
        } else {
            $_SESSION['msg1'] = "Error updating password. Please try again!";
        }
    }

    // Redirect to the same page to show the message
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 300);
}

if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 300);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Password Reset</title>
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
    <link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />

    <script type="text/javascript">
    function valid() {
        if (document.passwordreset.password.value != document.passwordreset.password_again.value) {
            alert("Password and Confirm Password do not match  !!");
            document.passwordreset.password_again.focus();
            return false;
        }
        return true;
    }
    </script>
</head>
<body class="login">
    <div class="row">
        <div class="main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
            <div class="logo margin-top-30">
                <a href="../index.html"><h2>Universal Hospital Management System | Reset Password</h2></a>
            </div>

            <div class="box-login">
                <form class="form-login" name="passwordreset" method="post" onSubmit="return valid();">
                    <fieldset>
                        <legend>
                            Reset Password
                        </legend>
                        <p>
                            Please set your new password.<br />
                            <span style="color:red;"><?php echo $_SESSION['msg1']; ?><?php echo $_SESSION['msg1'] = ""; ?></span>
                        </p>

                        <div class="form-group">
                            <span class="input-icon">
                                <input type="password" class="form-control" id="password" name="password" placeholder="New Password" required>
                                <i class="fa fa-lock"></i> 
                            </span>
                        </div>

                        <div class="form-group">
                            <span class="input-icon">
                                <input type="password" class="form-control" id="password_again" name="password_again" placeholder="Confirm Password" required>
                                <i class="fa fa-lock"></i> 
                            </span>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="btn btn-primary pull-right" name="submit">
                                Reset Password <i class="fa fa-arrow-circle-right"></i>
                            </button>
                        </div>

                        <div class="new-account">
                            Already have an account? 
                            <a href="index.php">
                                Log-in
                            </a>
                        </div>
                    </fieldset>
                </form>

                <div class="copyright">
                    &copy; <span class="current-year"></span><span class="text-bold text-uppercase"> Universal Hospital Management System</span>. <span>All rights reserved</span>
                </div>
            </div>
        </div>
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/modernizr/modernizr.js"></script>
    <script src="vendor/jquery-cookie/jquery.cookie.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="vendor/switchery/switchery.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/login.js"></script>
    <script>
        jQuery(document).ready(function() {
            Main.init();
            Login.init();
        });
    </script>

    <script>
    let timeout = <?php echo SESSION_TIMEOUT; ?>;
    let countdown = timeout;

    function updateCountdown() {
        countdown--;
        document.getElementById('countdown').innerText = countdown;

        if (countdown <= 0) {
            alert("Your session has expired. Please log in again.");
            window.location.href = "index.php?session_expired=1";
        }
    }

    setInterval(updateCountdown, 1000);
    </script>
</body>
</html>
