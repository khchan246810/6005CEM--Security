<?php
session_start();
include('include/config.php');
include('include/checklogin.php');
include ('include/session_check_patient.php');

check_login();
if (!defined('SESSION_TIMEOUT')) {
	define('SESSION_TIMEOUT', 300);
  }
// AES encryption and decryption functions
function aes_encrypt($data, $key) {
    // Initialization vector (IV) for AES encryption
    $iv = openssl_random_pseudo_bytes(16);
    // AES encryption
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, 0, $iv);
    // Return encrypted data with IV (IV is necessary for decryption)
    return base64_encode($encrypted . '::' . $iv);
}

// function aes_decrypt($data, $key) {
//     // Split the IV and encrypted data
//     list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
//     // AES decryption
//     return openssl_decrypt($encrypted_data, 'aes-256-cbc', $key, 0, $iv);
// }

$key = '0123456789'; // This should be a securely stored key

if(isset($_POST['submit'])) {
    $specilization = $_POST['Doctorspecialization'];
    $doctorid = $_POST['doctor'];
    $userid = $_SESSION['id'];
    $fees = aes_encrypt($_POST['fees'], $key); // Encrypt the fees before inserting into the database
    $appdate = aes_encrypt($_POST['appdate'], $key);
    $time =  aes_encrypt($_POST['apptime'], $key);
    $userstatus = 1;
    $docstatus = 1;

    // Insert encrypted data into the database
    $query = mysqli_query($con, "INSERT INTO appointment(doctorSpecialization, doctorId, userId, consultancyFees, appointmentDate, appointmentTime, userStatus, doctorStatus) VALUES('$specilization', '$doctorid', '$userid', '$fees', '$appdate', '$time', '$userstatus', '$docstatus')");

    if($query) {
		echo "<script>alert('Your appointment was successfully booked'); window.location.href = 'book-appointment.php';</script>";
	}
	
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>User | Book Appointment</title>
    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="assets/css/custom.min.css" rel="stylesheet">
    <script>
        function getdoctor(val) {
            $.ajax({
                type: "POST",
                url: "get_doctor.php",
                data: 'specilizationid=' + val,
                success: function(data) {
                    $("#doctor").html(data);
                }
            });
        }

        function getfee(val) {
            $.ajax({
                type: "POST",
                url: "get_doctor.php",
                data: 'doctor=' + val,
                success: function(data) {
                    $("#fees").html(data);
                }
            });
        }
    </script>
</head>
<body class="nav-md">
    <?php
    $page_title = 'User | Book Appointment';
    $x_content = true;
    ?>
    <?php include('include/header.php');?>
    <div class="row">
        <div class="col-md-12">
            <div class="row margin-top-30">
                <div class="col-lg-8 col-md-12">
                    <div class="panel panel-white">
                        <div class="panel-heading">
                            <h5 class="panel-title">Book Appointment</h5>
                        </div>
                        <div class="panel-body">
                            <form role="form" name="book" method="post">
                                <div class="form-group">
                                    <label for="DoctorSpecialization">Doctor Specialization</label>
                                    <select name="Doctorspecialization" class="form-control" onChange="getdoctor(this.value);" required="required">
                                        <option value="">Select Specialization</option>
                                        <?php
                                        $ret = mysqli_query($con, "select * from doctorspecilization");
                                        while($row = mysqli_fetch_array($ret)) {
                                        ?>
                                        <option value="<?php echo htmlentities($row['specilization']);?>">
                                            <?php echo htmlentities($row['specilization']);?>
                                        </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="doctor">Doctors</label>
                                    <select name="doctor" class="form-control" id="doctor" onChange="getfee(this.value);" required="required">
                                        <option value="">Select Doctor</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="consultancyfees">Consultancy Fees</label>
                                    <select name="fees" class="form-control" id="fees" readonly>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="AppointmentDate">Date</label>
                                    <input type="date" class="form-control" name="appdate" required="required" data-date-format="yyyy-mm-dd">
                                </div>
                                <div class="form-group">
                                    <label for="Appointmenttime">Time</label>
                                    <input type="time" class="form-control" name="apptime" id="time" required="required">eg : 10:00 PM
                                </div>
                                <button type="submit" name="submit" class="btn btn-o btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('include/footer.php');?>
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="vendors/fastclick/lib/fastclick.js"></script>
    <script src="vendors/nprogress/nprogress.js"></script>
    <script src="vendors/Chart.js/dist/Chart.min.js"></script>
    <script src="vendors/gauge.js/dist/gauge.min.js"></script>
    <script src="vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <script src="vendors/iCheck/icheck.min.js"></script>
    <script src="vendors/skycons/skycons.js"></script>
    <script src="vendors/Flot/jquery.flot.js"></script>
    <script src="vendors/Flot/jquery.flot.pie.js"></script>
    <script src="vendors/Flot/jquery.flot.time.js"></script>
    <script src="vendors/Flot/jquery.flot.stack.js"></script>
    <script src="vendors/Flot/jquery.flot.resize.js"></script>
    <script src="vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="vendors/flot.curvedlines/curvedLines.js"></script>
    <script src="vendors/DateJS/build/date.js"></script>
    <script src="vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="vendors/moment/min/moment.min.js"></script>
    <script src="vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
    <script src="assets/js/custom.min.js"></script>
    <script>
		let timeout = <?php echo SESSION_TIMEOUT; ?>;
		let countdown = timeout;

		function updateCountdown() {
			countdown--;
			document.getElementById('countdown').innerText = countdown;

			if (countdown <= 0) {
				alert("Your session has expired. Please log in again.");
				window.location.href = "index.php?session_expired=1";
			}
		}

		
		setInterval(updateCountdown, 1000);
	</script>
</body>
</html>