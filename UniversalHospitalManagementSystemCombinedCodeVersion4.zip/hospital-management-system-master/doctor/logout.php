<?php
session_start();
include('include/config.php');

// Reset the doctor login session variable
$_SESSION['dlogin'] = "";  // Single equal sign for assignment, not comparison

// Set the correct timezone for Malaysia Time (MYT)
date_default_timezone_set('Asia/Kuala_Lumpur');

// Capture the current date and time as logout time in Malaysia Time
$ldate = date('Y-m-d H:i:s', time());  // Malaysia Time (MYT)

// Update the doctor's logout time in the database
mysqli_query($con, "UPDATE doctorslog SET logout = '$ldate' WHERE uid = '".$_SESSION['id']."' AND logout IS NULL ORDER BY id DESC LIMIT 1");

// Clear the session
session_unset();
// session_destroy(); // Uncomment this line if you want to completely destroy the session

// Set a logout success message
$_SESSION['errmsg'] = "You have successfully logged out.";
?>
<script language="javascript">
    // Redirect to index page after successful logout
    document.location = "index.php";
</script>
