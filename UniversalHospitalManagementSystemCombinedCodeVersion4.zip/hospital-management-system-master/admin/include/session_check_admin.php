<?php
session_start(); 

// Define session timeout duration (in seconds)
define('SESSION_TIMEOUT', 300); // 5 minute

if (isset($_SESSION['last_activity'])) {
    $session_duration = time() - $_SESSION['last_activity'];
    
    // If session duration exceeds timeout limit, destroy the session
    if ($session_duration > SESSION_TIMEOUT) {
        session_unset(); // Unset all session variables
        //session_destroy(); // Destroy the session
        header("Location: index.php?session_expired=1"); // Redirect to login page with message
        exit();
    }
}

// Update the last activity timestamp to the current time
$_SESSION['last_activity'] = time();
?>
