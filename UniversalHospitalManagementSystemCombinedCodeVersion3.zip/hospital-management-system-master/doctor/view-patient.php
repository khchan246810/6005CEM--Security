<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
include('include/session_check_doctor.php');

check_login();
define(constant_name: 'ENCRYPTION_KEY', value: 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

function decrypt($dataDecrypt) {
    list($iv, $encrypted) = explode('::', base64_decode($dataDecrypt), 2);
    $cipher = "AES-128-CTR";
    return openssl_decrypt($encrypted, $cipher, ENCRYPTION_KEY, 0, $iv);
}
function encryptBP($bp) {
  $cipher = "AES-128-CTR";
  $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
  $encrypted = openssl_encrypt($bp, $cipher, ENCRYPTION_KEY, 0, $iv);
  return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}

function encryptBS($bs) {
  $cipher = "AES-128-CTR";
  $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
  $encrypted = openssl_encrypt($bs, $cipher, ENCRYPTION_KEY, 0, $iv);
  return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptWeight($weight) {
  $cipher = "AES-128-CTR";
  $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
  $encrypted = openssl_encrypt($weight, $cipher, ENCRYPTION_KEY, 0, $iv);
  return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptTemp($temp) {
  $cipher = "AES-128-CTR";
  $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
  $encrypted = openssl_encrypt($temp, $cipher, ENCRYPTION_KEY, 0, $iv);
  return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
function encryptPRES($pres) {
  $cipher = "AES-128-CTR";
  $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher)); // Generating a random IV
  $encrypted = openssl_encrypt($pres, $cipher, ENCRYPTION_KEY, 0, $iv);
  return base64_encode($iv . '::' . $encrypted); // Returning the IV and encrypted value as base64
}
if(isset($_POST['submit']))
{

  $vid=$_GET['viewid'];
  $bp=encryptBP($_POST['bp']);
  $bs=encryptBS($_POST['bs']);
  $weight=encryptWeight($_POST['weight']);
  $temp=encryptTemp($_POST['temp']);
  $pres=encryptPRES($_POST['pres']);


  $query.=mysqli_query($con, "insert tblmedicalhistory(PatientID,BloodPressure,BloodSugar,Weight,Temperature,MedicalPres)value('$vid','$bp','$bs','$weight','$temp','$pres')");
  if ($query) {
    echo '<script>alert("Medicle history has been added.")</script>';
    echo "<script>window.location.href ='manage-patient.php'</script>";
  }
  else
  {
    echo '<script>alert("Something Went Wrong. Please try again")</script>';
  }


}
if (!defined('SESSION_TIMEOUT')) {
	define('SESSION_TIMEOUT', 300);
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Doctor | Manage Patients</title>

  <!-- Bootstrap -->
  <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <!-- NProgress -->
  <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
  <!-- iCheck -->
  <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
  <!-- bootstrap-progressbar -->
  <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
  <!-- JQVMap -->
  <link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
  <!-- bootstrap-daterangepicker -->
  <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
  <!-- Custom Theme Style -->
  <link href="../assets/css/custom.css" rel="stylesheet">
  <body class="nav-md">
    <?php
    $page_title = 'Doctor | Manage Patients';
    $x_content = true;
    ?>
    <?php include('include/header.php');?>

    <div class="row">
      <div class="col-md-12">
        <h5 class="over-title margin-bottom-15">Manage <span class="text-bold">Patients</span></h5>
        <?php
        $vid=$_GET['viewid'];
        $ret=mysqli_query($con,"select * from tblpatient where ID='$vid'");
        $cnt=1;
        while ($row=mysqli_fetch_array($ret)) {
         ?>
         <table border="1" class="table table-bordered">
           <tr align="center">
            <td colspan="4" style="font-size:20px;color:blue">
            Patient Details</td></tr>

            <tr>
              <th scope>Patient Name</th>
              <td><?php  echo $row['PatientName'];?></td>
              <th scope>Patient Email</th>
              <td><?php  echo $row['PatientEmail'];?></td>
            </tr>
            <tr>
              <th scope>Patient Mobile Number</th>
              <td><?php  echo ($row['PatientContno']);?></td>
              <th>Patient Address</th>
              <td><?php  echo decrypt($row['PatientAdd']);?></td>
            </tr>
            <tr>
              <th>Patient Gender</th>
              <td><?php  echo decrypt($row['PatientGender']);?></td>
              <th>Patient Age</th>
              <td><?php  echo decrypt($row['PatientAge']);?></td>
            </tr>
            <tr>

              <th>Patient Medical History(if any)</th>
              <td><?php  echo decrypt($row['PatientMedhis']);?></td>
              <th>Patient Reg Date</th>
              <td><?php  echo $row['CreationDate'];?></td>
            </tr>
            </table>

          <?php }?>
        <?php

        $ret=mysqli_query($con,"select * from tblmedicalhistory  where PatientID='$vid'");



        ?>
        <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
          <tr align="center">
           <th colspan="8" >Medical History</th>
         </tr>
         <tr>
          <th>#</th>
          <th>Blood Pressure</th>
          <th>Weight</th>
          <th>Blood Sugar</th>
          <th>Body Temprature</th>
          <th>Medical Prescription</th>
          <th>Visit Date</th>
        </tr>
        <?php
        while ($row=mysqli_fetch_array($ret)) {
          ?>
          <tr>
            <td><?php echo $cnt;?></td>
            <td><?php echo decrypt($row['BloodPressure']);?></td>
            <td><?php echo decrypt($row['Weight']);?></td>
            <td><?php echo decrypt($row['BloodSugar']);?></td>
            <td><?php echo decrypt($row['Temperature']);?></td>
            <td><?php echo decrypt($row['MedicalPres']);?></td>
            <td><?php echo $row['CreationDate'];?></td>
          </tr>
          <?php $cnt=$cnt+1;} ?>
        </table>

        <p align="center">
         <button class="btn btn-primary waves-effect waves-light w-lg" data-toggle="modal" data-target="#myModal">Add Medical History</button></p>

         <?php  ?>
         <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
           <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Add Medical History</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <table class="table table-bordered table-hover data-tables">

               <form method="post" name="submit">

                <tr>
                  <th>Blood Pressure :</th>
                  <td>
                    <input name="bp" placeholder="Blood Pressure" class="form-control wd-450" required="true"></td>
                  </tr>
                  <tr>
                    <th>Blood Sugar :</th>
                    <td>
                      <input name="bs" placeholder="Blood Sugar" class="form-control wd-450" required="true"></td>
                    </tr>
                    <tr>
                      <th>Weight :</th>
                      <td>
                        <input name="weight" placeholder="Weight" class="form-control wd-450" required="true"></td>
                      </tr>
                      <tr>
                        <th>Body Temprature :</th>
                        <td>
                          <input name="temp" placeholder="Blood Sugar" class="form-control wd-450" required="true"></td>
                        </tr>

                        <tr>
                          <th>Prescription :</th>
                          <td>
                            <textarea name="pres" placeholder="Medical Prescription" rows="12" cols="14" class="form-control wd-450" required="true"></textarea></td>
                          </tr>

                        </table>
                      </div>
                      <div class="modal-footer">
                       <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                       <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                     </form>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
 </div>
</div>
</div>

<?php include('include/footer.php');?>
<!-- jQuery -->
<script src="../vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- FastClick -->
<script src="../vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="../vendors/nprogress/nprogress.js"></script>
<!-- Chart.js -->
<script src="../vendors/Chart.js/dist/Chart.min.js"></script>
<!-- gauge.js -->
<script src="../vendors/gauge.js/dist/gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="../vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="../vendors/iCheck/icheck.min.js"></script>
<!-- Skycons -->
<script src="../vendors/skycons/skycons.js"></script>
<!-- Flot -->
<script src="../vendors/Flot/jquery.flot.js"></script>
<script src="../vendors/Flot/jquery.flot.pie.js"></script>
<script src="../vendors/Flot/jquery.flot.time.js"></script>
<script src="../vendors/Flot/jquery.flot.stack.js"></script>
<script src="../vendors/Flot/jquery.flot.resize.js"></script>
<!-- Flot plugins -->
<script src="../vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
<script src="../vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
<script src="../vendors/flot.curvedlines/curvedLines.js"></script>
<!-- DateJS -->
<script src="../vendors/DateJS/build/date.js"></script>
<!-- JQVMap -->
<script src="../vendors/jqvmap/dist/jquery.vmap.js"></script>
<script src="../vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
<script src="../vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="../vendors/moment/min/moment.min.js"></script>
<script src="../vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- Custom Theme Scripts -->
<script src="../assets/js/custom.min.js"></script>

<script>
		let timeout = <?php echo SESSION_TIMEOUT; ?>;
		let countdown = timeout;

		function updateCountdown() {
			countdown--;
			document.getElementById('countdown').innerText = countdown;

			if (countdown <= 0) {
				alert("Your session has expired. Please log in again.");
				window.location.href = "index.php?session_expired=1";
			}
		}


		setInterval(updateCountdown, 1000);
	</script>
</body>
</html>