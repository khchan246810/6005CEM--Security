<?php
session_start();
error_reporting(E_ALL);  // Enable all error reporting for debugging
include('include/config.php');
include('include/checklogin.php');
include('include/session_check_patient.php');

// Ensure the user is logged in
check_login();

if (!defined('SESSION_TIMEOUT')) {
    define('SESSION_TIMEOUT', 300);
}
define('ENCRYPTION_KEY', 'b7gHjQ4LpZ0e3f*J8k@m!z5Q'); // Secure encryption key

// Decryption function
function decrypt($dataDecrypt) {
    list($iv, $encrypted) = explode('::', base64_decode($dataDecrypt), 2);
    $cipher = "AES-128-CTR";
    return openssl_decrypt($encrypted, $cipher, ENCRYPTION_KEY, 0, $iv);
}

// Debugging function to display data
function debug($msg) {
    echo "<pre>";
    var_dump($msg);
    echo "</pre>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reg Users | View Medical History</title>
    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="assets/css/custom.min.css" rel="stylesheet">
</head>
<body class="nav-md">
    <?php
    $page_title = 'Users | Medical History';
    $x_content = true;
    ?>
    <?php include('include/header.php'); ?>

    <div class="row">
        <div class="col-md-12">
            <h5 class="over-title margin-bottom-15">View <span class="text-bold">Medical History</span></h5>

            <!-- Debugging output -->
            <?php


            // Get the user ID from the session
            $uid = $_SESSION['id'];

            $docid=$_SESSION['id'];

            // SQL query to fetch patient details for the logged-in user
            $sql=mysqli_query($con,"select * from tblpatient where Docid='$docid' ");


           ?>

            <!-- Table to display medical history -->
            <table class="table table-hover" id="sample-table-1">
                <thead>
                    <tr>
                        <th class="center">#</th>
                        <th>Patient Name</th>
                        <th>Patient Contact Number</th>
                        <th>Patient Gender</th>
                        <th>Creation Date</th>
                        <th>Updation Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $cnt = 1;
                    while ($row = mysqli_fetch_array($sql)) {
                        // Debugging output for each row of data
                    ?>
                        <tr>
                            <td class="center"><?php echo $cnt; ?>.</td>
                            <td class="hidden-xs"><?php echo $row['PatientName']; ?></td>
                            <td><?php echo decrypt($row['PatientContno']); ?></td>
                            <td><?php echo decrypt($row['PatientGender']); ?></td>
                            <td><?php echo $row['CreationDate']; ?></td>
                            <td><?php echo $row['UpdationDate']; ?></td>
                            <td>
                                <a href="view-medhistory.php?viewid=<?php echo $row['ID']; ?>"><i class="fa fa-eye"></i></a>
                            </td>
                        </tr>
                    <?php
                        $cnt++;
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php include('include/footer.php'); ?>

    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FastClick -->
    <script src="vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="vendors/nprogress/nprogress.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="assets/js/custom.min.js"></script>
    <script>
        let timeout = <?php echo SESSION_TIMEOUT; ?>;
        let countdown = timeout;

        function updateCountdown() {
            countdown--;
            document.getElementById('countdown').innerText = countdown;

            if (countdown <= 0) {
                alert("Your session has expired. Please log in again.");
                window.location.href = "index.php?session_expired=1";
            }
        }

        setInterval(updateCountdown, 1000);
    </script>
</body>
</html>
