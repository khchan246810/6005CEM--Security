<?php
session_start();
include_once('include/config.php');

if (!isset($_SESSION['otp']) || !isset($_SESSION['pending_registration'])) {
    echo "<script>alert('No OTP request found.'); window.location='registration.php';</script>";
    exit();
}

$error_message = "";

if (isset($_POST['verify_otp'])) {
    $entered_otp = $_POST['otp'];

    // Check if OTP matches
    if ($entered_otp == $_SESSION['otp']) {
        // OTP is correct, insert user data into database
        $user_data = $_SESSION['pending_registration'];
        $query = mysqli_query($con, "INSERT INTO users (fullname, address, city, gender, email, password) VALUES ('{$user_data['fname']}', '{$user_data['address']}', '{$user_data['city']}', '{$user_data['gender']}', '{$user_data['email']}', '{$user_data['password']}')");

        if ($query) {
            echo "<script>alert('Successfully Registered. You can log in now'); window.location='index.php';</script>";

            // Clear session data after successful registration
            unset($_SESSION['otp']);
            unset($_SESSION['pending_registration']);
        }
    } else {
        $error_message = "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>OTP Verification</title>
</head>
<body>
    <h2>Enter OTP</h2>
    <form method="post">
        <label>OTP</label>
        <input type="text" name="otp" required>
        <button type="submit" name="verify_otp">Verify</button>
    </form>

    <?php if (!empty($error_message)) : ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php endif; ?>
</body>
</html>
