<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();

if(isset($_POST['submit'])) {
    // Check if the user has confirmed the deletion
    $sql = mysqli_query($con, "DELETE FROM userlog");
    if($sql) {
        $_SESSION['msg'] = "User logs deleted successfully!";
    } else {
        $_SESSION['msg'] = "Failed to delete user logs!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin | User Session Logs</title>
    <!-- Bootstrap -->
    <link href="../vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../vendors/jqvmap/dist/jqvmap.min.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../assets/css/custom.min.css" rel="stylesheet">
</head>
<body class="nav-md">
    <?php
    $page_title = 'Admin | User Session Logs';
    $x_content = true;
    ?>
    <?php include('include/header.php');?>
    <div class="row">
        <div class="col-md-12">
            <p style="color:red;"><?php echo htmlentities($_SESSION['msg'])?>
            <?php echo htmlentities($_SESSION['msg']="");?></p>
            <div class="panel-heading">
                <h5 class="panel-title">Delete all user logs</h5>
            </div>
            <div class="panel-body">
                <form method="POST" onSubmit="if(!confirm('Do you really want to delete all user session logs?')){return false;}">
                    <button type="submit" name="submit" class="btn btn-danger">Delete All Logs</button>
                </form>
            </div>

            <!-- Scrollable Table -->
            <div style="max-height: 400px; overflow-y: auto;">
                <table class="table table-hover" id="sample-table-1">
                    <thead>
                        <tr>
                            <th class="center">#</th>
                            <th class="hidden-xs">User ID</th>
                            <th>Username</th>
                            <th>User IP</th>
                            <th>Login Time</th>
                            <th>Logout Time</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql=mysqli_query($con,"SELECT * FROM userlog ");
                        $cnt=1;
                        while($row=mysqli_fetch_array($sql)) {
                            ?>
                            <tr>
                                <td class="center"><?php echo $cnt;?>.</td>
                                <td class="hidden-xs"><?php echo $row['uid'];?></td>
                                <td class="hidden-xs"><?php echo $row['username'];?></td>
                                <td><?php echo $row['userip'];?></td>
                                <td><?php echo $row['loginTime'];?></td>
                                <td><?php echo $row['logout'];?></td>
                                <td><?php echo $row['status'] == 1 ? 'Success' : 'Failed'; ?></td>
                            </tr>
                            <?php
                            $cnt++;
                        }?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php include('include/footer.php');?>
    <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="../assets/js/custom.min.js"></script>
</body>
</html>
